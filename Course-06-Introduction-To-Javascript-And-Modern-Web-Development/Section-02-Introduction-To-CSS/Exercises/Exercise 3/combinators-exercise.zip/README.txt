A Pen created at CodePen.io. You can find this one at http://codepen.io/imanuelgittens/pen/reKLPd.

 

Forked from [Modern Developer](http://codepen.io/team/moderndeveloper/)'s Pen [Combinators Exercise](http://codepen.io/team/moderndeveloper/pen/yOPqwm/).